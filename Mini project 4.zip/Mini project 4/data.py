import streamlit as st
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

# --- Load and preprocess data ---
@st.cache_data
def load_data():
    cleaned_df = pd.read_csv('cleaned_data.csv')
    encoded_df = pd.read_csv('encoded_data.csv', low_memory=False)

    # Normalize column names
    cleaned_df.columns = cleaned_df.columns.str.strip().str.lower()
    encoded_df.columns = encoded_df.columns.str.strip().str.lower()

    # Ensure all values in encoded_df are numeric
    encoded_df = encoded_df.apply(pd.to_numeric, errors='coerce')
    encoded_df = encoded_df.fillna(0)

    return cleaned_df, encoded_df

cleaned_df, encoded_df = load_data()

# --- Recommendation Engine ---
def recommend_restaurants(user_index, top_n=5):
    try:
        similarity_scores = cosine_similarity(
            [encoded_df.iloc[user_index]],
            encoded_df
        )[0]
        similar_indices = similarity_scores.argsort()[::-1][1:top_n+1]
        return cleaned_df.iloc[similar_indices]
    except Exception as e:
        st.error(f"Recommendation error: {e}")
        return pd.DataFrame()

# --- Streamlit UI ---
st.title("🍴 Restaurant Recommender")
st.markdown("This app recommends similar restaurants based on your selection.")

# Pick any restaurant as input
restaurant_names = cleaned_df['name'].dropna().unique() if 'name' in cleaned_df.columns else cleaned_df.index.astype(str)
selected_restaurant = st.selectbox("Select a restaurant you like:", restaurant_names)

# Find the index of the selected restaurant
try:
    if 'name' in cleaned_df.columns:
        user_index = cleaned_df[cleaned_df['name'] == selected_restaurant].index[0]
    else:
        user_index = int(selected_restaurant)
except Exception as e:
    st.error(f"Failed to find restaurant: {e}")
    st.stop()

# Generate and display recommendations
recommendations = recommend_restaurants(user_index=user_index, top_n=5)

if not recommendations.empty:
    st.subheader("🍽️ Top Recommended Restaurants:")
    st.dataframe(recommendations.reset_index(drop=True))
else:
    st.warning("No recommendations found.")
